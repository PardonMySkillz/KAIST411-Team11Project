#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

void c_free(void *ptr){
    free(ptr);
}

// TODOs
// implement a simple C functions whose functionality complies with restricted PyTorch functions
float* leaky_relu(float* input, int height, int width, float negative_slope){
    int input_size, output_size;
    input_size = output_size = height * width;
    float* output = (float*)malloc(output_size * sizeof(float));

    if(output == NULL) {
        return NULL;
    }

    // memset(output, 0.0, sizeof(float) * output_size);

    for (int h = 0; h < height; h++) {
        for (int w = 0; w < width; w++) {
            int index = h * width + w;
            float input_elem = input[index];
            output[index] = input_elem < 0 ? negative_slope * input_elem : input_elem;
        }
    }

    return output;

}

float* batch_norm(float* input, int batch_size, int channels, int height, int width, float* running_mean, float* running_variance, float* weight, float* bias){


    int size = batch_size * channels * height * width;
    float* output = (float*)malloc(size * sizeof(float));

    if(output == NULL) return NULL;

    memset(output, 0 , size * sizeof(float));
    float e = 1e-5;
    for (int batch = 0; batch < batch_size; batch ++) {
        for (int channel = 0; channel < channels; channel ++) {
            for (int i = 0; i < width * height; i++) {
                    int io_index = batch * channels * width * height + channel * height * width + i;
                    output[io_index] = weight[channel] * ((input[io_index] - running_mean[channel]) /(sqrt(running_variance[channel] + e))) + bias[channel];
            }
        }
    }

    return output;

}

float* conv2d(int batch_size, float* input, int input_channels, int input_height, int input_width,
              float* weight, float* bias, int kernel_height, int kernel_width,
              int output_channel, int output_height, int output_width, int stride) {
	// Compute the output dimensions

	int output_size = batch_size * output_channel * output_height * output_width;
	float* output = (float*)malloc(output_size * sizeof(float));
	if (output == NULL) {
		// Handle memory allocation error
		return NULL;
	}

	// Initialize output to zeros
	for (int i = 0; i < output_size; i++) {
		output[i] = 0.0;
	}

    // Perform the convolution
	for (int batch = 0; batch < batch_size; batch++){
	    for (int out_c = 0; out_c < output_channel; out_c++) {
            float bias_tmp = 0.0;
            if (bias != NULL){
                bias_tmp = bias[out_c];
            }
            for (int out_h = 0; out_h < output_height; out_h++) {
                for (int out_w = 0; out_w < output_width; out_w++) {
                    int i_h_start = out_h * stride;
                    int i_w_start = out_w * stride;
                    int output_index = batch*output_channel*output_height*output_width + out_c*output_height*output_width + out_h*output_width + out_w;
                    output[output_index] += bias_tmp;
                    for (int kernel_h = 0; kernel_h < kernel_height; kernel_h++) {
                        for (int kernel_w = 0; kernel_w < kernel_width; kernel_w++) {
                            for (int in_c = 0; in_c < input_channels; in_c++) {
                                int i_h = i_h_start + kernel_h;
                                int i_w = i_w_start + kernel_w;
                                if (i_h >= 0 && i_h < input_height && i_w >= 0 && i_w < input_width) {
                                    int input_index = batch*input_channels*input_height*input_width + in_c*input_height*input_width + i_h*input_width + i_w;
                                    int kernel_index = out_c*input_channels*kernel_height*kernel_width + in_c*kernel_height*kernel_width + kernel_h*kernel_width + kernel_w;
                                    output[output_index] += input[input_index] * weight[kernel_index];
                                }
                            }
                        }
                    }

                }
            }
	    }
	}
  
    return output;
}

void* max_pool2d(int batch_size, float* input, int input_channel, int input_height, int input_width, int kernel_height, int kernel_width, int stride) {
    int output_height = floor((input_height - kernel_height) / stride) + 1;
    int output_width = floor((input_width - kernel_width) / stride) + 1;
    int output_size = output_height * output_width * input_channel * batch_size;
    float* output = (float*)malloc(output_size * sizeof(float));
    if (output == NULL) {
        return NULL;
    }
    for (int b = 0; b < batch_size; b++) {
        for (int c = 0; c < input_channel; c++) {
            for (int row = 0; row < output_height; row++) {
                for (int col = 0; col < output_width; col++) {
                    int start_row = row * stride;
                    int start_col = col * stride;
                    float max_value = input[(b * input_channel * input_height * input_width) + (c * input_height * input_width) + (start_row * input_width) + start_col];
                    for (int i = 0; i < kernel_height; i++) {
                        for (int j = 0; j < kernel_width; j++) {
                            float curr_value = input[(b * input_channel * input_height * input_width) + (c * input_height * input_width) + ((start_row + i) * input_width) + (start_col + j)];
                            if (curr_value > max_value) {
                                max_value = curr_value;
                            }
                        }
                    }
                    output[(b * input_channel * output_height * output_width) + (c * output_height * output_width) + (row * output_width) + col] = max_value;
                }
            }
        }
    }
    return output;
}

float* pad(float* input_ptr, int batch_size, int channels, int height, int width, int left, int right, int top, int bottom, float padding) {
    int new_height = height+top+bottom;
    int new_width = width + left + right;
    float* output = (float*) malloc (sizeof(float) * batch_size * channels * new_height * new_width);
    
    float* ptri = input_ptr;
    float* ptro = output;
    for (int b = 0; b < batch_size; b++)
        for (int c = 0; c < channels; c++) {
            // Pad the top
            for (int i = 0; i < top * new_width; i++, ptro++)
                *ptro = padding;

            // Pad the middle
            for (int i = 0; i < height; i++) {
                // Left
                for (int j = 0; j < left; j++, ptro++)
                    *ptro = padding;
                // 
                for (int j = 0; j < height; j++, ptri++, ptro++)
                    *ptro = *ptri; 
                // Right
                for (int j = 0; j < right; j++, ptro++)
                    *ptro = padding;
            }

            // Pad the end
            for (int i = 0; i < bottom * new_width; i++, ptro++)
                *ptro = padding;
        }

    return output;
}
